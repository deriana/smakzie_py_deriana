import random

with open("story(happyending).txt","story(badending).txt", "r")as f:
    story =f.read()
    
print (story)